document.getElementById("showHeart").addEventListener("click", function() {
    let heart = document.getElementById("heart");
    heart.style.opacity = "1";
});
